# Upgrade Check

- OK: `True`
- Previous: `lyz-resume 1.1.0`
- Current: `lyz-resume 2.0.0`
- Declared bump: `major`
- Recommended bump: `patch`
- Breaking changes: `0`

## Upgrade Diff

- Added targets: `none`
- Removed targets: `none`
- Compatibility changes: `0`
- Metadata changes: `0`
- Checksum changes: `2`

## Release Notes

- Recommended version bump: patch.
- Package or archive checksum changed; reviewers should verify package artifacts before release.
- Package verification evidence: reports/package_verification.md.

## Failures

- None

## Warnings

- None
