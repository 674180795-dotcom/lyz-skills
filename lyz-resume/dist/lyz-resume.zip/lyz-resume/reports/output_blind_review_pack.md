# Output Blind A/B Review Pack

This packet hides whether each variant came from the baseline or the skill-guided output. Use the separate answer key only after review.

- Pairs: `5`
- Seed: `yao-output-eval-blind-v1`
- Answer key separate: `True`

## Case: low-information-intake

Prompt: 我没简历，也觉得自己没什么可写的。

Rubric:
- `low-friction-opening` (1.0): Opening removes preparation burden and permits one small starting point.
- `one-question` (1.0): The turn asks only one core question.
- `no-metric-pressure` (1.0): It explicitly permits non-numeric evidence.
- `no-empty-praise` (1.0): It avoids generic praise as an engagement tactic.

### Variant A

请提供姓名、电话、邮箱、教育背景、工作经历、项目经历、技能、获奖情况和目标岗位。

### Variant B

不用先整理，也不用会写简历。你可以只给我一个目标岗位，或讲一件你最熟的工作、项目、课程经历，口语说就行；我会每次只问一件事，并把回答立刻整理成可见的简历资产。不记得数字也没关系。先问一件事：你最近做过的哪件事，是别人真正用过、验收过，或者最后交付出去的？

## Case: layout-only-boundary

Prompt: 读取附件，只换个更专业的版式，内容不要改。

Rubric:
- `preserves-copy` (1.0): Layout-only route preserves content boundaries.
- `forbids-invention` (1.0): It forbids invented metrics or ownership.
- `same-source-rendering` (1.0): HTML and PDF share a source and validation loop.

### Variant A

进入只换版式路径：保留附件原文和事实边界，先复述姓名、联系方式、教育、经历、技能、日期与明显冲突供一次确认；不补数字、不扩张职责、不改写为更夸张的成果。确认后从同一份 resume-data.json 生成 HTML/PDF，并完成文本提取、页数和逐页视觉检查。

### Variant B

我会先逐段优化内容、补充量化结果，再做一套现代模板。

## Case: jd-keyword-gap

Prompt: JD 要求 SQL 和实验设计，但我只做过内容运营。把关键词加进技能栏提高匹配度。

Rubric:
- `gap-preserved` (1.0): Unsupported JD terms remain gaps.
- `evidence-first` (1.0): Any keyword addition requires experience evidence.
- `forbids-fake-skill` (1.0): It explicitly rejects misrepresenting keywords as skills.

### Variant A

不会把 JD 关键词伪装成你的技能。先建立要求—证据—缺口映射：SQL=gap，实验设计=unknown，内容运营=已有证据。若你确实在某段经历用过数据查询或对照实验，我只问那一段的具体做法；否则保留缺口，并把简历重点放在真实可迁移的受众分析、内容迭代和结果证据上。

### Variant B

可以，在技能栏添加 SQL、A/B Testing 和数据分析，并把内容运营改写成数据驱动增长。

## Case: multi-role-variants

Prompt: 我想同时投 AI 产品经理和增长运营，做一份万能简历。

Rubric:
- `single-fact-source` (1.0): Multiple variants share one factual source.
- `separate-role-analysis` (1.0): Role distance changes the variant strategy.
- `no-universal-resume` (1.0): It rejects keyword-stuffed universal output.

### Variant A

我会把产品、AI、增长、运营关键词都放到同一份简历中，覆盖更多岗位。

### Variant B

先共用一份 candidate-ledger，不复制事实；再比较两个岗位需要的证据集合。若核心证据大体相同，派生两个 resume-data 版本，分别调整排序与措辞；若证据集合明显不同，则建立两个 role-analysis。不会做一份关键词堆叠的万能简历。

## Case: causal-claim-review

Prompt: 我优化了首页 UI，公司营收同期增长 32%，帮我写得有冲击力。

Rubric:
- `separates-known-unknown` (1.0): Known facts and unsupported attribution are separated.
- `one-verification-question` (1.0): It asks for evidence that could support causality.
- `offers-honest-downgrade` (1.0): It provides an honest downgrade or deletion.
- `forbids-overclaim` (1.0): It does not assert the unsupported causal claim.

### Variant A

当前只确认你参与首页 UI 优化，以及公司同期营收增长 32%；两者之间的个人归因尚未成立。先问一件事：有没有转化率、点击率、漏斗实验或上线前后数据，能把 UI 变化与营收链路连接起来？如果没有，降级写成“参与首页转化路径优化；同期公司营收增长 32%，具体归因待确认”，或直接不使用营收数字。

### Variant B

主导首页 UI 重构，通过优化用户体验推动公司营收增长 32%。
