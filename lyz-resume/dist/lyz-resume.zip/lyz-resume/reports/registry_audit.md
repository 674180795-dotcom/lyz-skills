# Registry Audit

- OK: `True`
- Package: `lyz-resume`
- Version: `1.0.0`
- Maturity: `production`
- Owner: `Ling99`
- License: `MIT`
- Package SHA256: `ef3d9949d8cf8bf93f8fbaa1065e3befdbae6933d528e3ec712780658d3b0ce2`
- Archive SHA256: `n/a`
- Install simulated: `False`

## Compatibility

| Target | Status |
| --- | --- |
| `openai` | `pass` |
| `claude` | `pass` |
| `agent-skills` | `pass` |
| `vscode` | `pass` |
| `generic` | `pass` |
| `agent-skills-compatible` | `pass` |

## Failures

- None

## Warnings

- None

## Artifacts

- index: `/Users/ling99/Codexfiles/Codex/.agents/skills/lyz-resume/registry/index.json`
- package: `/Users/ling99/Codexfiles/Codex/.agents/skills/lyz-resume/registry/packages/lyz-resume.json`
- json: `/Users/ling99/Codexfiles/Codex/.agents/skills/lyz-resume/reports/registry_audit.json`
- markdown: `/Users/ling99/Codexfiles/Codex/.agents/skills/lyz-resume/reports/registry_audit.md`
