# Python Compatibility

Generated at: `2026-09-18`

## Summary

- decision: `pass`
- target python: `3.11`
- files scanned: `9`
- issues: `0`
- syntax errors: `0`
- f-string 3.11 violations: `0`

This report catches Python syntax and compatibility hazards that can pass on a newer local interpreter but fail in the supported CI/runtime interpreter.

## Issues

| Path | Line | Rule | Message |
| --- | ---: | --- | --- |
| `none` | 0 | `none` | none |
