# Package Verification

- OK: `True`
- Package directory: `/Users/ling99/Codexfiles/Codex/.agents/skills/lyz-resume/dist`
- Targets: `4 / 4` adapters present
- Archive present: `True`
- Archive SHA256: `b576b6db1cf27ced2cdc063df7a55747996ef250225a8b695879008fd1f60693`
- Failures: `0`
- Warnings: `0`

## Checks

| Check | Status | Detail |
| --- | --- | --- |
| `package-manifest` | `pass` | Package manifest exists: /Users/ling99/Codexfiles/Codex/.agents/skills/lyz-resume/dist/manifest.json |
| `claude-adapter` | `pass` | Adapter exists for target: claude |
| `generic-adapter` | `pass` | Adapter exists for target: generic |
| `openai-adapter` | `pass` | Adapter exists for target: openai |
| `vscode-adapter` | `pass` | Adapter exists for target: vscode |
| `archive-safe-paths` | `pass` | Archive has no absolute or parent-traversal entries |
| `archive-entry-lyz-resume/SKILL.md` | `pass` | Archive contains lyz-resume/SKILL.md |
| `archive-entry-lyz-resume/manifest.json` | `pass` | Archive contains lyz-resume/manifest.json |
| `archive-entry-lyz-resume/agents/interface.yaml` | `pass` | Archive contains lyz-resume/agents/interface.yaml |
| `archive-excludes-generated` | `pass` | Archive excludes generated dist/, .previews/, and tests/tmp* contents |
| `registry-ok` | `pass` | Registry audit is OK |
| `registry-name-match` | `pass` | Registry package name matches package manifest |
| `registry-version-match` | `pass` | Registry package version matches package manifest |
| `registry-compat-claude` | `pass` | Registry compatibility is reviewable for target: claude |
| `registry-compat-generic` | `pass` | Registry compatibility is reviewable for target: generic |
| `registry-compat-openai` | `pass` | Registry compatibility is reviewable for target: openai |
| `registry-compat-vscode` | `pass` | Registry compatibility is reviewable for target: vscode |

## Failures

- None

## Warnings

- None
