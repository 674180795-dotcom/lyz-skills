# Package Verification

- OK: `False`
- Package directory: `/Users/ling99/Codexfiles/Codex/lyz-skills-release/lyz-resume/dist`
- Targets: `1 / 4` adapters present
- Archive present: `True`
- Archive SHA256: `4f080f97ce1870c0c84e3a8ce4d301c852b447ced2f53665fdd6c92bc57a7cd0`
- Failures: `88`
- Warnings: `0`

## Checks

| Check | Status | Detail |
| --- | --- | --- |
| `package-manifest` | `pass` | Package manifest exists: /Users/ling99/Codexfiles/Codex/lyz-skills-release/lyz-resume/dist/manifest.json |
| `openai-adapter` | `fail` | Adapter exists for target: openai |
| `openai-field-name` | `fail` | openai adapter includes field: name |
| `openai-field-description` | `fail` | openai adapter includes field: description |
| `openai-field-version` | `fail` | openai adapter includes field: version |
| `openai-field-display_name` | `fail` | openai adapter includes field: display_name |
| `openai-field-short_description` | `fail` | openai adapter includes field: short_description |
| `openai-field-default_prompt` | `fail` | openai adapter includes field: default_prompt |
| `openai-field-job_to_be_done` | `fail` | openai adapter includes field: job_to_be_done |
| `openai-field-ir_source` | `fail` | openai adapter includes field: ir_source |
| `openai-field-ir_schema_version` | `fail` | openai adapter includes field: ir_schema_version |
| `openai-field-semantic_contract` | `fail` | openai adapter includes field: semantic_contract |
| `openai-field-semantic_parity` | `fail` | openai adapter includes field: semantic_parity |
| `openai-field-compiler` | `fail` | openai adapter includes field: compiler |
| `openai-field-compiled_contract` | `fail` | openai adapter includes field: compiled_contract |
| `openai-field-permission_contract` | `fail` | openai adapter includes field: permission_contract |
| `openai-field-target_permission_contract` | `fail` | openai adapter includes field: target_permission_contract |
| `openai-field-target_native_contract` | `fail` | openai adapter includes field: target_native_contract |
| `openai-field-target_transform` | `fail` | openai adapter includes field: target_transform |
| `openai-field-canonical_metadata` | `fail` | openai adapter includes field: canonical_metadata |
| `openai-field-canonical_format` | `fail` | openai adapter includes field: canonical_format |
| `openai-field-activation_mode` | `fail` | openai adapter includes field: activation_mode |
| `openai-field-execution_context` | `fail` | openai adapter includes field: execution_context |
| `openai-field-shell` | `fail` | openai adapter includes field: shell |
| `openai-field-trust_level` | `fail` | openai adapter includes field: trust_level |
| `openai-field-remote_inline_execution` | `fail` | openai adapter includes field: remote_inline_execution |
| `openai-field-degradation_strategy` | `fail` | openai adapter includes field: degradation_strategy |
| `openai-field-portability_profile` | `fail` | openai adapter includes field: portability_profile |
| `claude-adapter` | `fail` | Adapter exists for target: claude |
| `claude-field-name` | `fail` | claude adapter includes field: name |
| `claude-field-description` | `fail` | claude adapter includes field: description |
| `claude-field-version` | `fail` | claude adapter includes field: version |
| `claude-field-display_name` | `fail` | claude adapter includes field: display_name |
| `claude-field-short_description` | `fail` | claude adapter includes field: short_description |
| `claude-field-default_prompt` | `fail` | claude adapter includes field: default_prompt |
| `claude-field-job_to_be_done` | `fail` | claude adapter includes field: job_to_be_done |
| `claude-field-ir_source` | `fail` | claude adapter includes field: ir_source |
| `claude-field-ir_schema_version` | `fail` | claude adapter includes field: ir_schema_version |
| `claude-field-semantic_contract` | `fail` | claude adapter includes field: semantic_contract |
| `claude-field-semantic_parity` | `fail` | claude adapter includes field: semantic_parity |
| `claude-field-compiler` | `fail` | claude adapter includes field: compiler |
| `claude-field-compiled_contract` | `fail` | claude adapter includes field: compiled_contract |
| `claude-field-permission_contract` | `fail` | claude adapter includes field: permission_contract |
| `claude-field-target_permission_contract` | `fail` | claude adapter includes field: target_permission_contract |
| `claude-field-target_native_contract` | `fail` | claude adapter includes field: target_native_contract |
| `claude-field-target_transform` | `fail` | claude adapter includes field: target_transform |
| `claude-field-canonical_metadata` | `fail` | claude adapter includes field: canonical_metadata |
| `claude-field-canonical_format` | `fail` | claude adapter includes field: canonical_format |
| `claude-field-activation_mode` | `fail` | claude adapter includes field: activation_mode |
| `claude-field-execution_context` | `fail` | claude adapter includes field: execution_context |
| `claude-field-shell` | `fail` | claude adapter includes field: shell |
| `claude-field-trust_level` | `fail` | claude adapter includes field: trust_level |
| `claude-field-remote_inline_execution` | `fail` | claude adapter includes field: remote_inline_execution |
| `claude-field-degradation_strategy` | `fail` | claude adapter includes field: degradation_strategy |
| `claude-field-portability_profile` | `fail` | claude adapter includes field: portability_profile |
| `generic-adapter` | `pass` | Adapter exists for target: generic |
| `generic-field-name` | `pass` | generic adapter includes field: name |
| `generic-field-description` | `pass` | generic adapter includes field: description |
| `generic-field-version` | `pass` | generic adapter includes field: version |
| `generic-field-display_name` | `pass` | generic adapter includes field: display_name |
| `generic-field-short_description` | `pass` | generic adapter includes field: short_description |
| `generic-field-default_prompt` | `pass` | generic adapter includes field: default_prompt |
| `generic-field-job_to_be_done` | `pass` | generic adapter includes field: job_to_be_done |
| `generic-field-ir_source` | `pass` | generic adapter includes field: ir_source |
| `generic-field-ir_schema_version` | `pass` | generic adapter includes field: ir_schema_version |
| `generic-field-semantic_contract` | `pass` | generic adapter includes field: semantic_contract |
| `generic-field-semantic_parity` | `pass` | generic adapter includes field: semantic_parity |
| `generic-field-compiler` | `pass` | generic adapter includes field: compiler |
| `generic-field-compiled_contract` | `pass` | generic adapter includes field: compiled_contract |
| `generic-field-permission_contract` | `pass` | generic adapter includes field: permission_contract |
| `generic-field-target_permission_contract` | `pass` | generic adapter includes field: target_permission_contract |
| `generic-field-target_native_contract` | `pass` | generic adapter includes field: target_native_contract |
| `generic-field-target_transform` | `pass` | generic adapter includes field: target_transform |
| `generic-field-canonical_metadata` | `pass` | generic adapter includes field: canonical_metadata |
| `generic-field-canonical_format` | `pass` | generic adapter includes field: canonical_format |
| `generic-field-activation_mode` | `pass` | generic adapter includes field: activation_mode |
| `generic-field-execution_context` | `pass` | generic adapter includes field: execution_context |
| `generic-field-shell` | `pass` | generic adapter includes field: shell |
| `generic-field-trust_level` | `pass` | generic adapter includes field: trust_level |
| `generic-field-remote_inline_execution` | `pass` | generic adapter includes field: remote_inline_execution |
| `generic-field-degradation_strategy` | `pass` | generic adapter includes field: degradation_strategy |
| `generic-field-portability_profile` | `pass` | generic adapter includes field: portability_profile |
| `vscode-adapter` | `fail` | Adapter exists for target: vscode |
| `vscode-field-name` | `fail` | vscode adapter includes field: name |
| `vscode-field-description` | `fail` | vscode adapter includes field: description |
| `vscode-field-version` | `fail` | vscode adapter includes field: version |
| `vscode-field-display_name` | `fail` | vscode adapter includes field: display_name |
| `vscode-field-short_description` | `fail` | vscode adapter includes field: short_description |
| `vscode-field-default_prompt` | `fail` | vscode adapter includes field: default_prompt |
| `vscode-field-job_to_be_done` | `fail` | vscode adapter includes field: job_to_be_done |
| `vscode-field-ir_source` | `fail` | vscode adapter includes field: ir_source |
| `vscode-field-ir_schema_version` | `fail` | vscode adapter includes field: ir_schema_version |
| `vscode-field-semantic_contract` | `fail` | vscode adapter includes field: semantic_contract |
| `vscode-field-semantic_parity` | `fail` | vscode adapter includes field: semantic_parity |
| `vscode-field-compiler` | `fail` | vscode adapter includes field: compiler |
| `vscode-field-compiled_contract` | `fail` | vscode adapter includes field: compiled_contract |
| `vscode-field-permission_contract` | `fail` | vscode adapter includes field: permission_contract |
| `vscode-field-target_permission_contract` | `fail` | vscode adapter includes field: target_permission_contract |
| `vscode-field-target_native_contract` | `fail` | vscode adapter includes field: target_native_contract |
| `vscode-field-target_transform` | `fail` | vscode adapter includes field: target_transform |
| `vscode-field-canonical_metadata` | `fail` | vscode adapter includes field: canonical_metadata |
| `vscode-field-canonical_format` | `fail` | vscode adapter includes field: canonical_format |
| `vscode-field-activation_mode` | `fail` | vscode adapter includes field: activation_mode |
| `vscode-field-execution_context` | `fail` | vscode adapter includes field: execution_context |
| `vscode-field-shell` | `fail` | vscode adapter includes field: shell |
| `vscode-field-trust_level` | `fail` | vscode adapter includes field: trust_level |
| `vscode-field-remote_inline_execution` | `fail` | vscode adapter includes field: remote_inline_execution |
| `vscode-field-degradation_strategy` | `fail` | vscode adapter includes field: degradation_strategy |
| `vscode-field-portability_profile` | `fail` | vscode adapter includes field: portability_profile |
| `openai-file-targets/openai/adapter.json` | `fail` | Package contains targets/openai/adapter.json |
| `openai-file-targets/openai/agents/openai.yaml` | `fail` | Package contains targets/openai/agents/openai.yaml |
| `claude-file-targets/claude/adapter.json` | `fail` | Package contains targets/claude/adapter.json |
| `claude-file-targets/claude/README.md` | `fail` | Package contains targets/claude/README.md |
| `generic-file-targets/generic/adapter.json` | `pass` | Package contains targets/generic/adapter.json |
| `vscode-file-targets/vscode/adapter.json` | `fail` | Package contains targets/vscode/adapter.json |
| `vscode-file-targets/vscode/README.md` | `fail` | Package contains targets/vscode/README.md |
| `archive-safe-paths` | `pass` | Archive has no absolute or parent-traversal entries |
| `archive-entry-lyz-resume/SKILL.md` | `pass` | Archive contains lyz-resume/SKILL.md |
| `archive-entry-lyz-resume/manifest.json` | `pass` | Archive contains lyz-resume/manifest.json |
| `archive-entry-lyz-resume/agents/interface.yaml` | `pass` | Archive contains lyz-resume/agents/interface.yaml |
| `archive-excludes-generated` | `pass` | Archive excludes generated dist/, .previews/, and tests/tmp* contents |
| `registry-ok` | `pass` | Registry audit is OK |
| `registry-name-match` | `pass` | Registry package name matches package manifest |
| `registry-version-match` | `fail` | Registry package version matches package manifest |
| `registry-compat-openai` | `pass` | Registry compatibility is reviewable for target: openai |
| `registry-compat-claude` | `pass` | Registry compatibility is reviewable for target: claude |
| `registry-compat-generic` | `pass` | Registry compatibility is reviewable for target: generic |
| `registry-compat-vscode` | `pass` | Registry compatibility is reviewable for target: vscode |

## Failures

- Adapter exists for target: openai
- openai adapter includes field: name
- openai adapter includes field: description
- openai adapter includes field: version
- openai adapter includes field: display_name
- openai adapter includes field: short_description
- openai adapter includes field: default_prompt
- openai adapter includes field: job_to_be_done
- openai adapter includes field: ir_source
- openai adapter includes field: ir_schema_version
- openai adapter includes field: semantic_contract
- openai adapter includes field: semantic_parity
- openai adapter includes field: compiler
- openai adapter includes field: compiled_contract
- openai adapter includes field: permission_contract
- openai adapter includes field: target_permission_contract
- openai adapter includes field: target_native_contract
- openai adapter includes field: target_transform
- openai adapter includes field: canonical_metadata
- openai adapter includes field: canonical_format
- openai adapter includes field: activation_mode
- openai adapter includes field: execution_context
- openai adapter includes field: shell
- openai adapter includes field: trust_level
- openai adapter includes field: remote_inline_execution
- openai adapter includes field: degradation_strategy
- openai adapter includes field: portability_profile
- Adapter exists for target: claude
- claude adapter includes field: name
- claude adapter includes field: description
- claude adapter includes field: version
- claude adapter includes field: display_name
- claude adapter includes field: short_description
- claude adapter includes field: default_prompt
- claude adapter includes field: job_to_be_done
- claude adapter includes field: ir_source
- claude adapter includes field: ir_schema_version
- claude adapter includes field: semantic_contract
- claude adapter includes field: semantic_parity
- claude adapter includes field: compiler
- claude adapter includes field: compiled_contract
- claude adapter includes field: permission_contract
- claude adapter includes field: target_permission_contract
- claude adapter includes field: target_native_contract
- claude adapter includes field: target_transform
- claude adapter includes field: canonical_metadata
- claude adapter includes field: canonical_format
- claude adapter includes field: activation_mode
- claude adapter includes field: execution_context
- claude adapter includes field: shell
- claude adapter includes field: trust_level
- claude adapter includes field: remote_inline_execution
- claude adapter includes field: degradation_strategy
- claude adapter includes field: portability_profile
- Adapter exists for target: vscode
- vscode adapter includes field: name
- vscode adapter includes field: description
- vscode adapter includes field: version
- vscode adapter includes field: display_name
- vscode adapter includes field: short_description
- vscode adapter includes field: default_prompt
- vscode adapter includes field: job_to_be_done
- vscode adapter includes field: ir_source
- vscode adapter includes field: ir_schema_version
- vscode adapter includes field: semantic_contract
- vscode adapter includes field: semantic_parity
- vscode adapter includes field: compiler
- vscode adapter includes field: compiled_contract
- vscode adapter includes field: permission_contract
- vscode adapter includes field: target_permission_contract
- vscode adapter includes field: target_native_contract
- vscode adapter includes field: target_transform
- vscode adapter includes field: canonical_metadata
- vscode adapter includes field: canonical_format
- vscode adapter includes field: activation_mode
- vscode adapter includes field: execution_context
- vscode adapter includes field: shell
- vscode adapter includes field: trust_level
- vscode adapter includes field: remote_inline_execution
- vscode adapter includes field: degradation_strategy
- vscode adapter includes field: portability_profile
- Package contains targets/openai/adapter.json
- Package contains targets/openai/agents/openai.yaml
- Package contains targets/claude/adapter.json
- Package contains targets/claude/README.md
- Package contains targets/vscode/adapter.json
- Package contains targets/vscode/README.md
- Registry package version matches package manifest

## Warnings

- None
