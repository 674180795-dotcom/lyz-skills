# Runtime Conformance Matrix

- Skill: `lyz-aircraft-embroidery`
- Targets: `1`
- Passed: `1`
- Failed: `0`

| Target | Status | Failures | Warnings |
| --- | --- | --- | --- |
| openai | pass | None | None |

## Reviewer Notes

- Failed targets block release for that target.
- Warnings identify lossy or not-yet-compiled behavior that must remain visible.
